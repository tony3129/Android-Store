package com.tonyliu.assignment3;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ProductDetails extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_product_details);

        ImageView ivProdImgDetails = findViewById(R.id.ivProdImgDetails);
        TextView tvProdNameDetails = findViewById(R.id.tvProdNameDetails);
        TextView tvProdDescDetails = findViewById(R.id.tvProdDescDetails);
        TextView tvProdPriceDetails = findViewById(R.id.tvProdPriceDetails);
        Button btnAddToCart = findViewById(R.id.btnAddToCart);

        Bundle productDetails = getIntent().getExtras();

        tvProdNameDetails.setText(productDetails.getString("productName"));
        tvProdDescDetails.setText(productDetails.getString("productDesc"));
        tvProdPriceDetails.setText(productDetails.getString("productPrice"));
        ivProdImgDetails.setImageResource(productDetails.getInt("productImage"));


        btnAddToCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(ProductDetails.this,tvProdNameDetails.getText().toString() + " Added to Cart", Toast.LENGTH_SHORT).show();
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}